from .Behavior_Analytics import main

if __name__ == "__main__":
    main()
