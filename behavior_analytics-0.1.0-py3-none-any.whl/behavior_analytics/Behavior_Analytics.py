import sys
import os
import json
import tkinter as tk
from tkinter import scrolledtext, messagebox, Radiobutton, StringVar, filedialog
import webbrowser
import cv2
import mediapipe as mp
import threading
import pygetwindow as gw
import time
from pynput import mouse
import numpy as np
import csv 
from datetime import datetime
import pytz
from threading import Lock
from collections import deque
from deepface import DeepFace
from pathlib import Path

from importlib import resources

DEFAULT_SETTINGS = {
    "timezone": "Asia/Kolkata",
    "camera_indices": [0, 1, 2],
    "camera_resolutions": [
        [1280, 720],
        [1024, 768],
        [800, 600],
        [640, 480],
        [320, 240]
    ],
    "heatmap_scale": 4,
    "behavior_thresholds": {
        "nail_biting_distance": 60,
        "hand_flapping_speed": 100,
        "head_movement_speed": 130
    },
    "browser_keywords": [
        "chrome", "firefox", "edge", "opera", "brave",
        "safari", "vlc", "flash"
    ],
    "gui_sizes": {
        "main": "620x820",
        "log": "940x720"
    },
    "save_base_dir": "ChildBehaviorAnalytics"
}

def load_settings():
    settings = DEFAULT_SETTINGS.copy()
    
    config_path = Path(__file__).with_name("settings.json")
    if config_path.exists():
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                file_cfg = json.load(f)
            settings.update(file_cfg)
            print(f"Loaded settings from {config_path}")
        except Exception as e:
            print(f"Error reading settings.json: {e}")

    env_overrides = {
        "CBA_TIMEZONE": "timezone",
        "CBA_SAVE_DIR": "save_base_dir"
    }
    for env_var, key in env_overrides.items():
        if os.getenv(env_var):
            settings[key] = os.getenv(env_var)
            print(f"Overridden {key} from environment variable {env_var}")

    return settings

SETTINGS = load_settings()

try:
    from screeninfo import get_monitors
    SCREENINFO_AVAILABLE = True
    print("screeninfo loaded successfully.")
except ImportError:
    SCREENINFO_AVAILABLE = False
    print("screeninfo not installed. Using fallback screen resolution 1920x1080.")


class BehaviorAnalyticsGUI:
    def __init__(self, parent, heatmap_data, data_lock):
        self.parent = parent
        self.window = tk.Toplevel(parent)
        self.window.title("Live Behavior & Emotion Log")
        self.window.geometry(SETTINGS["gui_sizes"]["log"])
        self.window.configure(bg='#f8f9fa')
        self.data_lock = data_lock
        self.heatmap_data = heatmap_data
        self.update_scheduled = False

        tk.Label(self.window, text="Real-Time Behavior & Emotion Detection",
                 font=('Arial', 18, 'bold'), bg='#f8f9fa', fg='#2c3e50').pack(pady=20)

        self.text_area = scrolledtext.ScrolledText(self.window, width=115, height=36,
                                                  font=('Consolas', 10), bg='white', fg='#2c3e50', state='disabled')
        self.text_area.pack(padx=20, pady=10, fill=tk.BOTH, expand=True)
        self.window.protocol("WM_DELETE_WINDOW", self.on_close)
        self.update_log()

    def update_log(self):
        if not self.window.winfo_exists():
            return
        if self.update_scheduled:
            return
        self.update_scheduled = True
        self.window.after(1500, self._update)

    def _update(self):
        try:
            self.text_area.config(state='normal')
            self.text_area.delete(1.0, tk.END)
            with self.data_lock:
                recent = list(self.heatmap_data)[-80:]
                for entry in recent:
                    beh = entry.get('behavior', '')
                    if beh:
                        line = f"{entry['timestamp']} | {beh:50} | {entry['ChildID']} | {entry['activity']}\n"
                        self.text_area.insert(tk.END, line)
            self.text_area.see(tk.END)
            self.text_area.config(state='disabled')
        except Exception as e:
            print(f"GUI update error: {e}")
        finally:
            self.update_scheduled = False
            self.update_log()

    def on_close(self):
        try:
            self.window.destroy()
        except:
            pass


class WebGameApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Child Behavior Analytics System")
        self.root.geometry(SETTINGS["gui_sizes"]["main"])
        self.root.configure(bg='#ecf0f1')
        self.root.resizable(False, False)

        self.btn_style = {'font': ('Arial', 12, 'bold'), 'fg': 'white', 'relief': 'flat', 'padx': 30, 'pady': 14, 'cursor': 'hand2'}
        self.label_style = {'bg': '#ecf0f1', 'font': ('Arial', 12), 'pady': 10}

        tk.Label(self.root, text="Child Behavior Analytics", font=('Arial', 20, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(pady=25)

        # Child ID
        f1 = tk.Frame(self.root, bg='#ecf0f1')
        f1.pack(pady=12)
        tk.Label(f1, text="Child ID:", **self.label_style).pack(side=tk.LEFT)
        self.child_id_entry = tk.Entry(f1, font=('Arial', 12), width=20, justify='center')
        self.child_id_entry.pack(side=tk.LEFT, padx=10)
        self.child_id_entry.insert(0, "Enter ID")
        self.child_id_entry.bind("<FocusIn>", lambda e: self.child_id_entry.delete(0, tk.END) if self.child_id_entry.get() == "Enter ID" else None)

        # Activity Input
        content_frame = tk.Frame(self.root, bg='#ecf0f1')
        content_frame.pack(pady=20, fill=tk.X, padx=30)
        tk.Label(content_frame, text="Activity:", font=('Arial', 13, 'bold'), bg='#ecf0f1', fg='#2c3e50').pack(anchor=tk.W)

        # URL
        url_frame = tk.Frame(content_frame, bg='#ecf0f1')
        url_frame.pack(fill=tk.X, pady=8)
        tk.Label(url_frame, text="Web URL:", **self.label_style).pack(side=tk.LEFT)
        self.url_entry = tk.Entry(url_frame, font=('Arial', 11), width=48)
        self.url_entry.pack(side=tk.LEFT, padx=8, fill=tk.X, expand=True)
        self.url_entry.insert(0, "https://")

        # Local File
        file_frame = tk.Frame(content_frame, bg='#ecf0f1')
        file_frame.pack(fill=tk.X, pady=8)
        tk.Label(file_frame, text="Local File:", **self.label_style).pack(side=tk.LEFT)
        self.file_entry = tk.Entry(file_frame, font=('Arial', 11), width=38)
        self.file_entry.pack(side=tk.LEFT, padx=8, fill=tk.X, expand=True)
        self.file_entry.insert(0, "Click 'Browse' to select HTML/SWF file")
        self.file_entry.config(state='readonly')
        tk.Button(file_frame, text="Browse", command=self.browse_file, bg='#3498db', activebackground='#2980b9', **self.btn_style).pack(side=tk.LEFT, padx=5)

        # Behavior Toggle
        f3 = tk.Frame(self.root, bg='#ecf0f1')
        f3.pack(pady=25)
        tk.Label(f3, text="Behavior Detection:", **self.label_style).pack(side=tk.LEFT)
        self.behavior_var = StringVar(value="on")
        tk.Radiobutton(f3, text="ON", variable=self.behavior_var, value="on", bg='#ecf0f1', command=self.toggle_behavior_on).pack(side=tk.LEFT, padx=15)
        tk.Radiobutton(f3, text="OFF", variable=self.behavior_var, value="off", bg='#ecf0f1', command=self.toggle_behavior_off).pack(side=tk.LEFT)

        tk.Button(self.root, text="Start Tracking", command=self.start_tracking, bg='#27ae60', activebackground='#1e8449', **self.btn_style).pack(pady=15)
        tk.Button(self.root, text="Generate Report", command=self.save_heatmap_data, bg='#e67e22', activebackground='#d35400', **self.btn_style).pack(pady=10)

        tk.Button(self.root, text="Click here to visualize", command=self.open_visualizer,
                  bg='#9b59b6', activebackground='#8e44ad', fg='white',
                  font=('Arial', 12, 'bold'), relief='flat', padx=30, pady=14, cursor='hand2').pack(pady=12)

        # Screen Resolution Detection
        if SCREENINFO_AVAILABLE:
            try:
                monitors = get_monitors()
                primary = next((m for m in monitors if m.is_primary), monitors[0])
                self.screen_width = primary.width
                self.screen_height = primary.height
                print(f"Detected primary screen: {self.screen_width}x{self.screen_height}")
            except Exception as e:
                print(f"Screen detection failed ({e}); using fallback 1920x1080")
                self.screen_width, self.screen_height = 1920, 1080
        else:
            print("screeninfo not available; using fallback resolution 1920x1080")
            self.screen_width, self.screen_height = 1920, 1080

        # Camera Initialization 
        self.cap = None
        self.frame_width = 640
        self.frame_height = 480

        for idx in SETTINGS["camera_indices"]:
            temp_cap = cv2.VideoCapture(idx)
            if not temp_cap.isOpened():
                continue
            for w, h in SETTINGS["camera_resolutions"]:
                temp_cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
                temp_cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
                actual_w = int(temp_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                actual_h = int(temp_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                if abs(actual_w - w) < 10 and abs(actual_h - h) < 10:
                    self.cap = temp_cap
                    self.frame_width = actual_w
                    self.frame_height = actual_h
                    print(f"Camera opened at index {idx}: {actual_w}x{actual_h}")
                    break
            if self.cap:
                break
            temp_cap.release()

        if not self.cap or not self.cap.isOpened():
            messagebox.showerror("Camera Error", "No webcam detected or accessible.")
            self.cap = None

        # MediaPipe Setup
        mp_face_mesh = mp.solutions.face_mesh
        mp_hands = mp.solutions.hands
        self.face_mesh = mp_face_mesh.FaceMesh(max_num_faces=1, refine_landmarks=True,
                                              min_detection_confidence=0.6, min_tracking_confidence=0.6)
        self.hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.6, min_tracking_confidence=0.6)
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        self.eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye.xml")

        # Heatmap
        scale = SETTINGS["heatmap_scale"]
        self.heatmap = np.zeros((self.frame_height * scale, self.frame_width * scale), dtype=np.float32)

        # State Variables
        self.tracking_active = False
        self.behavior_detection_active = True
        self.behavior_gui = None
        self.current_url = ""
        self.current_file_path = ""
        self.current_activity_name = "Activity"
        self.heatmap_data = deque(maxlen=50000)
        self.data_lock = Lock()
        self.mouse_clicks = deque(maxlen=2000)
        self.hand_positions = deque(maxlen=15)
        self.face_positions = deque(maxlen=15)
        self.last_mouse_move_time = time.time()
        self.ist = pytz.timezone(SETTINGS["timezone"])

        # Emotion tracking variables
        self.emotion_episodes = []          
        self.current_emotion = None         
        self.current_emotion_start = None   

        # Attention tracking
        self.attention_detected = False
        self.attention_start_time = None

        # Fullscreen support for camera window
        self.fullscreen = False
        self.camera_window_name = "Child Behavior Analytics - Press 'f' for Fullscreen, 'q' to stop"

        # Save Directory
        self.base_dir = Path.home() / "Desktop" / SETTINGS["save_base_dir"]
        self.base_dir.mkdir(parents=True, exist_ok=True)

        # Mouse Listener
        self.mouse_listener = mouse.Listener(on_move=self.on_mouse_move, on_click=self.on_mouse_click)
        self.mouse_listener.start()

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)


    def open_visualizer(self):
        """Open visuvalization_graph.html from the package's static folder"""
        try:
            # Preferred: Use importlib.resources (works in installed package)
            with resources.as_file(resources.files('behavior_analytics.static') / 'visuvalization_graph.html') as html_path:
                if html_path.exists():
                    webbrowser.open(html_path.as_uri())
                else:
                    raise FileNotFoundError

            messagebox.showinfo(
                "Visualizer Opened",
                "Visualization opened successfully!\n\nDrag your generated CSV files onto the page to view charts."
            )

        except Exception as e:
            # Fallback for development or edge cases
            try:
                dev_path = Path(__file__).parent / "static" / "visuvalization_graph.html"
                if dev_path.exists():
                    webbrowser.open(dev_path.as_uri())
                    messagebox.showinfo("Visualizer Opened", "Visualization opened from local static folder.")
                    return
            except:
                pass

            messagebox.showerror(
                "Visualizer Error",
                f"Could not find or open visuvalization_graph.html\n\n"
                f"Error: {str(e)}\n\n"
                f"Ensure the file exists in behavior_analytics/static/"
            )

    def browse_file(self):
        file_path = filedialog.askopenfilename(
            title="Select Activity File",
            filetypes=[("Web Files", "*.html *.htm *.swf"), ("All Files", "*.*")]
        )
        if file_path:
            self.current_file_path = file_path
            self.file_entry.config(state='normal')
            self.file_entry.delete(0, tk.END)
            self.file_entry.insert(0, os.path.basename(file_path))
            self.file_entry.config(state='readonly')
            self.current_activity_name = os.path.splitext(os.path.basename(file_path))[0]

    def start_tracking(self):
        child_id = self.child_id_entry.get().strip()
        if not child_id or child_id == "Enter ID":
            messagebox.showwarning("Required", "Please enter Child ID!")
            return

        url = self.url_entry.get().strip()
        has_url = url and url.startswith("http")
        has_file = bool(self.current_file_path)

        if not has_url and not has_file:
            messagebox.showwarning("No Content", "Please enter a URL or select a local file!")
            return

        if self.cap is None or not self.cap.isOpened():
            messagebox.showwarning("Camera Not Available", "Camera is not accessible. Connect a webcam.")
            return

        if has_url:
            self.current_url = url
            self.current_activity_name = url.split("/")[-1].split("?")[0] or "WebSession"
            webbrowser.open(url)
        elif has_file:
            self.open_local_file(self.current_file_path)

        if not self.tracking_active:
            self.tracking_active = True
            threading.Thread(target=self.track_eyes, daemon=True).start()

    def open_local_file(self, file_path):
        if not os.path.exists(file_path):
            messagebox.showerror("Error", "File not found!")
            return
        file_url = Path(file_path).as_uri()
        try:
            webbrowser.open(file_url)
        except:
            try:
                os.startfile(file_path)
            except:
                messagebox.showerror("Error", "Could not open file.")

    def toggle_behavior_on(self):
        self.behavior_detection_active = True
        if not self.behavior_gui:
            self.behavior_gui = BehaviorAnalyticsGUI(self.root, self.heatmap_data, self.data_lock)

    def toggle_behavior_off(self):
        self.behavior_detection_active = False
        if self.behavior_gui:
            self.behavior_gui.on_close()
            self.behavior_gui = None

    def on_mouse_move(self, x, y):
        self.last_mouse_move_time = time.time()

    def on_mouse_click(self, x, y, button, pressed):
        if pressed and self.tracking_active:
            win = gw.getActiveWindow()
            if win and win.title:
                title = win.title.lower()
                if any(keyword in title for keyword in SETTINGS["browser_keywords"]):
                    rel_x = x - win.left
                    rel_y = y - win.top
                    if 0 <= rel_x < win.width and 0 <= rel_y < win.height:
                        self.mouse_clicks.append((rel_x, rel_y, time.time(), win.width, win.height))

    def detect_behaviors(self, frame, face_landmarks, hand_landmarks, h, w):
        behaviors = []
        child_id = self.child_id_entry.get().strip() or "Unknown"
        timestamp = datetime.now(self.ist).strftime("%Y-%m-%d %H:%M:%S")
        y_offset = 80
        th = SETTINGS["behavior_thresholds"]

        try:
            if face_landmarks and hand_landmarks:
                mouth = face_landmarks.landmark[13]
                mx, my = int(mouth.x * w), int(mouth.y * h)
                for hand in hand_landmarks:
                    tip = hand.landmark[8]
                    fx, fy = int(tip.x * w), int(tip.y * h)
                    dist = ((fx - mx)**2 + (fy - my)**2)**0.5
                    if dist < th["nail_biting_distance"]:
                        behaviors.append("Nail Biting")
                        cv2.putText(frame, "Nail Biting!", (20, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,0,255), 2)
                        y_offset += 40

            if hand_landmarks:
                wrist = hand_landmarks[0].landmark[0]
                pos = (int(wrist.x * w), int(wrist.y * h))
                self.hand_positions.append((pos, time.time()))
                if len(self.hand_positions) >= 12:
                    speeds = [np.linalg.norm(np.array(self.hand_positions[i][0]) - np.array(self.hand_positions[i-1][0])) /
                              max(0.001, self.hand_positions[i][1] - self.hand_positions[i-1][1])
                              for i in range(1, len(self.hand_positions))]
                    if len(speeds) > 6 and np.mean(speeds[-6:]) > th["hand_flapping_speed"]:
                        behaviors.append("Hand Flapping")
                        cv2.putText(frame, "Hand Flapping!", (20, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,0,255), 2)
                        y_offset += 40

            if face_landmarks:
                nose = face_landmarks.landmark[1]
                pos = (int(nose.x * w), int(nose.y * h))
                self.face_positions.append((pos, time.time()))
                if len(self.face_positions) >= 12:
                    speeds = [np.linalg.norm(np.array(self.face_positions[i][0]) - np.array(self.face_positions[i-1][0])) /
                              max(0.001, self.face_positions[i][1] - self.face_positions[i-1][1])
                              for i in range(1, len(self.face_positions))]
                    if len(speeds) > 6 and np.mean(speeds[-6:]) > th["head_movement_speed"]:
                        behaviors.append("Rapid Head Movement")
                        cv2.putText(frame, "Head Movement!", (20, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,0,255), 2)
                        y_offset += 40

            try:
                result = DeepFace.analyze(frame, actions=['emotion'], enforce_detection=False, silent=True)
                emotion = result[0]['dominant_emotion'].title() if result else "Neutral"
                current_time = time.time()

                if emotion != self.current_emotion:
                    if self.current_emotion is not None and self.current_emotion_start is not None:
                        duration = current_time - self.current_emotion_start
                        if duration > 1.0:
                            self.emotion_episodes.append({
                                'emotion': self.current_emotion,
                                'start_time': datetime.fromtimestamp(self.current_emotion_start, self.ist).strftime("%Y-%m-%d %H:%M:%S"),
                                'end_time': datetime.fromtimestamp(current_time, self.ist).strftime("%Y-%m-%d %H:%M:%S"),
                                'duration_seconds': round(duration, 1)
                            })
                            behaviors.append(f"Emotion: {self.current_emotion} (duration: {round(duration, 1)}s)")

                    self.current_emotion = emotion
                    self.current_emotion_start = current_time

                cv2.putText(frame, f"Emotion: {emotion}", (20, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,215,0), 2)
                y_offset += 40

            except Exception as e:
                print(f"DeepFace emotion error: {e}")
                if self.current_emotion is None:
                    self.current_emotion = "Neutral"
                    self.current_emotion_start = time.time()

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(gray, 1.1, 6, minSize=(100,100))
            eyes_found = 0
            for (x, y, fw, fh) in faces:
                roi = gray[y:y+fh, x:x+fw]
                eyes_found += len(self.eye_cascade.detectMultiScale(roi))

            if eyes_found >= 2:
                if not self.attention_detected:
                    self.attention_detected = True
                    self.attention_start_time = time.time()
                    behaviors.append("Attention Started")
                duration = time.time() - self.attention_start_time
                cv2.putText(frame, f"ATTENTION ({duration:.1f}s)", (20, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,255,0), 2)
            else:
                if self.attention_detected:
                    duration = time.time() - self.attention_start_time
                    behaviors.append(f"Attention Lost ({duration:.1f}s)")
                    self.attention_detected = False
                cv2.putText(frame, "No Attention", (20, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (100,100,100), 2)

            for b in behaviors:
                with self.data_lock:
                    self.heatmap_data.append({
                        'timestamp': timestamp,
                        'behavior': b,
                        'ChildID': child_id,
                        'activity': self.current_activity_name
                    })

        except Exception as e:
            print(f"Behavior detection error: {e}")

        return frame

    def track_eyes(self):
        scale = SETTINGS["heatmap_scale"]
        cv2.namedWindow(self.camera_window_name, cv2.WINDOW_NORMAL)
        cv2.setWindowProperty(self.camera_window_name, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_NORMAL)  # Start windowed

        while self.tracking_active:
            if self.cap is None or not self.cap.isOpened():
                break
            ret, frame = self.cap.read()
            if not ret:
                messagebox.showwarning("Camera Lost", "Camera disconnected. Tracking stopped.")
                self.tracking_active = False
                break

            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            face_results = self.face_mesh.process(rgb)
            hand_results = self.hands.process(rgb)

            child_id = self.child_id_entry.get().strip() or "Unknown"
            timestamp = datetime.now(self.ist).strftime("%Y-%m-%d %H:%M:%S")
            h, w = frame.shape[:2]

            face_landmarks = face_results.multi_face_landmarks[0] if face_results.multi_face_landmarks else None
            hand_landmarks = hand_results.multi_hand_landmarks

            if self.behavior_detection_active:
                frame = self.detect_behaviors(frame, face_landmarks, hand_landmarks, h, w)

            if face_landmarks:
                nose = face_landmarks.landmark[1]
                if 0.3 < nose.x < 0.7 and (time.time() - self.last_mouse_move_time) < 6:
                    gx = int(nose.x * w * scale)
                    gy = int(nose.y * h * scale)
                    cv2.circle(self.heatmap, (gx, gy), 45, 1.8, -1)
                    with self.data_lock:
                        self.heatmap_data.append({
                            'timestamp': timestamp, 'behavior': 'Gaze Focus', 'ChildID': child_id,
                            'activity': self.current_activity_name
                        })

            while self.mouse_clicks:
                rx, ry, click_time, win_w, win_h = self.mouse_clicks.popleft()
                norm_x = rx / win_w
                norm_y = ry / win_h
                cam_x = norm_x * w
                cam_y = norm_y * h
                heat_x = int(cam_x * scale)
                heat_y = int(cam_y * scale)
                cv2.circle(self.heatmap, (heat_x, heat_y), 70, 20, -1)
                with self.data_lock:
                    self.heatmap_data.append({
                        'timestamp': datetime.fromtimestamp(click_time, self.ist).strftime("%Y-%m-%d %H:%M:%S"),
                        'behavior': 'Mouse Click', 'ChildID': child_id, 'activity': self.current_activity_name
                    })

            # Display text on frame (visible in both modes)
            cv2.putText(frame, f"ID: {child_id} | {self.current_activity_name[:30]} | Press 'f' for Fullscreen | 'q' to quit",
                        (8, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)

            # Handle fullscreen toggle and resize
            key = cv2.waitKey(1) & 0xFF
            if key == ord('f'):
                self.fullscreen = not self.fullscreen
                if self.fullscreen:
                    cv2.setWindowProperty(self.camera_window_name, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
                    screen_w = self.root.winfo_screenwidth()
                    screen_h = self.root.winfo_screenheight()
                    display_frame = cv2.resize(frame, (screen_w, screen_h))
                else:
                    cv2.setWindowProperty(self.camera_window_name, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_NORMAL)
                    display_frame = cv2.resize(frame, (1280, 720))
                    cv2.resizeWindow(self.camera_window_name, 1280, 720)
            else:
                
                if self.fullscreen:
                    screen_w = self.root.winfo_screenwidth()
                    screen_h = self.root.winfo_screenheight()
                    display_frame = cv2.resize(frame, (screen_w, screen_h))
                else:
                    display_frame = frame  

            cv2.imshow(self.camera_window_name, display_frame)

            if key == ord('q'):
                break
        if self.cap:
            self.cap.release()
        cv2.destroyAllWindows()
        self.tracking_active = False

    def save_heatmap_data(self):
        try:
            with self.data_lock:
                if not self.heatmap_data and not self.emotion_episodes:
                    messagebox.showinfo("No Data", "No tracking data collected yet.")
                    return

                child_id = self.child_id_entry.get().strip() or "Unknown"
                safe_id = "".join(c if c.isalnum() or c in " _-()" else "_" for c in child_id)
                folder = self.base_dir / safe_id
                folder.mkdir(parents=True, exist_ok=True)
                ts = datetime.now(self.ist).strftime("%Y%m%d_%H%M%S")

                files_generated = []

                behavior_rows = [e for e in self.heatmap_data if e.get('behavior')]
                if behavior_rows:
                    csv_path = folder / f"BEHAVIORS_{safe_id}_{ts}.csv"
                    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.DictWriter(f, fieldnames=['timestamp', 'behavior', 'ChildID', 'activity'])
                        writer.writeheader()
                        writer.writerows(behavior_rows)
                    files_generated.append("BEHAVIORS.csv")

                emotion_rows = []
                if self.current_emotion and self.current_emotion_start:
                    final_duration = time.time() - self.current_emotion_start
                    if final_duration > 1.0:
                        end_time = datetime.now(self.ist)
                        emotion_rows.append({
                            'timestamp': end_time.strftime("%Y-%m-%d %H:%M:%S"),
                            'behavior': f"Emotion: {self.current_emotion} (duration: {round(final_duration, 1)}s)",
                            'ChildID': child_id,
                            'activity': self.current_activity_name
                        })

                for ep in self.emotion_episodes:
                    emotion_rows.append({
                        'timestamp': ep['end_time'],
                        'behavior': f"Emotion: {ep['emotion']} (duration: {ep['duration_seconds']}s)",
                        'ChildID': child_id,
                        'activity': self.current_activity_name
                    })

                if emotion_rows:
                    emotions_csv_path = folder / f"EMOTIONS_{safe_id}_{ts}.csv"
                    with open(emotions_csv_path, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.DictWriter(f, fieldnames=['timestamp', 'behavior', 'ChildID', 'activity'])
                        writer.writeheader()
                        writer.writerows(emotion_rows)
                    files_generated.append("EMOTIONS.csv")

                if np.any(self.heatmap):
                    blurred = cv2.GaussianBlur(self.heatmap, (51, 51), 0)
                    norm = cv2.normalize(blurred, None, 0, 255, cv2.NORM_MINMAX)
                    heatmap_color = cv2.applyColorMap(np.uint8(norm), cv2.COLORMAP_JET)
                    heatmap_color = cv2.resize(heatmap_color, (self.frame_width, self.frame_height))
                    overlay = heatmap_color.copy()
                    cv2.putText(overlay, f"Child: {child_id}", (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (255,255,255), 3)
                    cv2.putText(overlay, f"Activity: {self.current_activity_name}", (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (200,200,255), 2)
                    cv2.putText(overlay, f"Screen: {self.screen_width}x{self.screen_height}", (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (200,200,200), 2)
                    cv2.putText(overlay, f"Generated: {ts}", (10, self.frame_height - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (180,180,180), 1)
                    img_path = folder / f"HEATMAP_{safe_id}_{ts}.png"
                    cv2.imwrite(str(img_path), overlay)
                    files_generated.append("HEATMAP.png")

                msg = f"Report Generated Successfully!\n\nChild: {child_id}\nFiles: {', '.join(files_generated) or 'None'}\n\nSaved in:\n{folder}"
                messagebox.showinfo("Success", msg)
                if messagebox.askyesno("Open Folder", "Open the folder now?"):
                    os.startfile(str(folder))

        except Exception as e:
            messagebox.showerror("Error", f"Save failed:\n{e}")

    def on_close(self):
        self.tracking_active = False
        if self.behavior_gui:
            self.behavior_gui.on_close()

        if self.current_emotion and self.current_emotion_start:
            final_duration = time.time() - self.current_emotion_start
            if final_duration > 1.0:
                self.emotion_episodes.append({
                    'emotion': self.current_emotion,
                    'start_time': datetime.fromtimestamp(self.current_emotion_start, self.ist).strftime("%Y-%m-%d %H:%M:%S"),
                    'end_time': datetime.now(self.ist).strftime("%Y-%m-%d %H:%M:%S"),
                    'duration_seconds': round(final_duration, 1)
                })

        self.save_heatmap_data()
        if self.cap:
            self.cap.release()
        cv2.destroyAllWindows()
        try:
            self.mouse_listener.stop()
        except:
            pass
        self.root.quit()


def main():
    root = tk.Tk()
    app = WebGameApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()