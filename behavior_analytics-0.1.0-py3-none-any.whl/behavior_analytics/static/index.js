const VEGETABLES = [
    { id: "carrot", name: "Carrot", emoji: "🥕" },
    { id: "tomato", name: "Tomato", emoji: "🍅" },
    { id: "potato", name: "Potato", emoji: "🥔" },
    { id: "onion", name: "Onion", emoji: "🧅" },
    { id: "brinjal", name: "Brinjal", emoji: "🍆" },
    { id: "beans", name: "Beans", emoji: "🫘" },
    { id: "cauliflower", name: "Cauliflower", emoji: "🥦" },
];

let score = 0;
let completedItems = 0;
let currentScreen = 'welcome';

const basketList = document.getElementById("basketList");
const platesGrid = document.getElementById("platesGrid");
const scoreValue = document.getElementById("scoreValue");
const progressFill = document.getElementById("progressFill");
const heartsContainer = document.getElementById("heartsContainer");

// Speech synthesis for feedback
function speakMessage(message) {
    if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(message);
        utterance.rate = 0.9;
        utterance.pitch = 1.1;
        utterance.volume = 0.8;
        speechSynthesis.speak(utterance);
    }
}

// Sound effects using Web Audio API
function playSuccessSound() {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime); // C5
    oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.1); // E5
    oscillator.frequency.setValueAtTime(783.99, audioContext.currentTime + 0.2); // G5

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
}

function playErrorSound() {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.setValueAtTime(300, audioContext.currentTime);
    oscillator.frequency.setValueAtTime(250, audioContext.currentTime + 0.1);

    gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.2);
}

function createFloatingHearts(x, y) {
    for (let i = 0; i < 5; i++) {
        const heart = document.createElement('div');
        heart.className = 'heart';
        heart.innerHTML = ['💖', '💕', '💗', '💝', '❤️'][Math.floor(Math.random() * 5)];
        heart.style.left = (x - 10 + Math.random() * 20) + 'px';
        heart.style.top = (y - 10 + Math.random() * 20) + 'px';
        heart.style.animationDelay = (i * 0.1) + 's';
        heartsContainer.appendChild(heart);

        setTimeout(() => heart.remove(), 3000);
    }
}

function createConfetti() {
    for (let i = 0; i < 30; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        confetti.style.left = Math.random() * window.innerWidth + 'px';
        confetti.style.animationDelay = (Math.random() * 2) + 's';
        document.body.appendChild(confetti);

        setTimeout(() => confetti.remove(), 2000);
    }
}

function showCelebrationMessage() {
    const message = document.createElement('div');
    message.className = 'celebration-message';
    message.innerHTML = '🎉 Awesome Job! You matched all the veggies! 🎉';
    document.body.appendChild(message);

    setTimeout(() => message.remove(), 3000);
}

function updateProgress() {
    const percentage = (completedItems / VEGETABLES.length) * 100;
    progressFill.style.width = percentage + '%';

    if (completedItems === VEGETABLES.length) {
        setTimeout(() => {
            createConfetti();
            showCelebrationMessage();
        }, 500);
    }
}

function createBasketVeggies() {
    basketList.innerHTML = '';
    VEGETABLES.forEach(veg => {
        const div = document.createElement("div");
        div.className = "veggie";
        div.draggable = true;
        div.id = "drag-" + veg.id;
        div.innerHTML = `${veg.emoji}`;

        div.addEventListener("dragstart", e => {
            e.dataTransfer.setData("text/plain", veg.id);
            div.classList.add('wiggle');
            div.classList.add('dragging');
        });

        div.addEventListener("dragend", () => {
            div.classList.remove('wiggle');
            div.classList.remove('dragging');
        });

        div.addEventListener("mouseenter", () => {
            div.style.transform = "translateY(-5px) scale(1.05)";
        });

        div.addEventListener("mouseleave", () => {
            div.style.transform = "";
        });

        basketList.appendChild(div);
    });
}

function createPlates() {
    platesGrid.innerHTML = '';
    VEGETABLES.forEach(veg => {
        const plate = document.createElement("div");
        plate.className = "plate";
        plate.dataset.id = veg.id;
        plate.innerHTML = `<div style="font-size: 1em; margin-bottom: 3px; font-weight: bold;">${veg.name}</div><div style="font-size: 0.7em; color: #666;">Drop here!</div>`;

        // Enhanced drag interactions
        plate.addEventListener("dragover", e => {
            e.preventDefault();
            plate.classList.add("drag-over");
        });

        plate.addEventListener("dragleave", () => {
            plate.classList.remove("drag-over");
        });

        plate.addEventListener("drop", e => {
            e.preventDefault();
            plate.classList.remove("drag-over");
            const vegId = e.dataTransfer.getData("text/plain");
            const draggedVeg = VEGETABLES.find(v => v.id === vegId);

            if (vegId === veg.id) {
                // Correct match!
                playSuccessSound();
                speakMessage("Good Job");
                plate.classList.add('completed');
                plate.innerHTML = `
                            <div style="font-size: 2.5em; margin-bottom: 5px;">${draggedVeg.emoji}</div>
                            <div style="font-size: 0.9em; font-weight: bold;">${veg.name}</div>
                            <div class="feedback success">✅ Perfect!</div>
                        `;

                // Create hearts at the plate position
                const rect = plate.getBoundingClientRect();
                createFloatingHearts(rect.left + rect.width / 2, rect.top + rect.height / 2);

                // Hide the dragged veggie
                document.getElementById("drag-" + vegId).style.display = "none";

                // Update score
                completedItems++;
                score = completedItems;
                scoreValue.textContent = score;
                updateProgress();

            } else {
                // Wrong match
                playErrorSound();
                speakMessage("Try Again");
                const errorMsg = document.createElement('div');
                errorMsg.className = 'feedback error';
                errorMsg.innerHTML = '❌ Try Again!';
                plate.appendChild(errorMsg);

                // Shake animation
                plate.style.animation = 'none';
                setTimeout(() => {
                    plate.style.animation = 'wiggle 0.5s ease-in-out';
                }, 10);

                setTimeout(() => {
                    if (errorMsg && errorMsg.parentNode) {
                        errorMsg.remove();
                    }
                    plate.style.animation = '';
                }, 2000);
            }
        });

        platesGrid.appendChild(plate);
    });
}

function resetGame() {
    score = 0;
    completedItems = 0;
    scoreValue.textContent = '0';
    progressFill.style.width = '0%';

    createBasketVeggies();
    createPlates();

    // Add a little celebration for starting fresh
    const resetMsg = document.createElement('div');
    resetMsg.className = 'celebration-message';
    resetMsg.innerHTML = '🚀 New Game Started! Have Fun! 🚀';
    resetMsg.style.fontSize = '1.5em';
    document.body.appendChild(resetMsg);
    setTimeout(() => resetMsg.remove(), 2000);
}

// Initialize game
createBasketVeggies();
createPlates();

// Add some welcome animation
window.addEventListener('load', () => {
    setTimeout(() => {
        const veggies = document.querySelectorAll('.veggie');
        const plates = document.querySelectorAll('.plate');

        veggies.forEach((veggie, index) => {
            setTimeout(() => {
                veggie.style.animation = 'bounce 1s ease-out';
            }, index * 200);
        });

        plates.forEach((plate, index) => {
            setTimeout(() => {
                plate.style.animation = 'fadeInScale 0.8s ease-out';
            }, index * 300);
        });
    }, 500);
});


function showScreen(screenId) {
    const screens = document.querySelectorAll('.screen');

    // Remove active class from all screens
    screens.forEach(screen => {
        screen.classList.remove('active');
    });

    // Add active class to target screen
    const targetScreen = document.getElementById(screenId + 'Screen');
    if (targetScreen) {
        setTimeout(() => {
            targetScreen.classList.add('active');

            // Add voice messages for each screen
            setTimeout(() => {
                if (screenId === 'welcome') {
                    speakMessage("Let us learn about the vegetables");
                } else if (screenId === 'instruction') {
                    speakMessage("Drag the Vegetable and put it in a right plate");
                } else if (screenId === 'game') {
                    speakMessage("Let's start matching vegetables!");
                }
            }, 500); // Small delay to let screen transition

        }, 100);
        currentScreen = screenId;
    }
}

function initializeScreens() {
    const welcomeStartBtn = document.getElementById('welcomeStartBtn');
    const instructionStartBtn = document.getElementById('instructionStartBtn');
    const backBtn = document.getElementById('backBtn');
    const homeIcons = document.querySelectorAll('.home-icon');

    // Welcome screen to instruction screen
    welcomeStartBtn.addEventListener('click', () => {
        showScreen('instruction');
    });

    // Instruction screen to game screen
    instructionStartBtn.addEventListener('click', () => {
        showScreen('game');
        initializeGame();
    });

    // Back button to welcome screen
    backBtn.addEventListener('click', () => {
        showScreen('welcome');
        resetGameState();
    });

    // Home icons to welcome screen
    homeIcons.forEach(icon => {
        icon.addEventListener('click', () => {
            showScreen('welcome');
            resetGameState();
        });
    });
}

function resetGameState() {
    score = 0;
    completedItems = 0;
    if (scoreValue) scoreValue.textContent = '0';
    if (progressFill) progressFill.style.width = '0%';
}
function initializeGame() {
    createBasketVeggies();
    createPlates();
    updateProgress();
}

function resetGame() {
    resetGameState();
    initializeGame();
    speakMessage("Game reset! Try again!");
}

// Add this to your existing DOMContentLoaded or initialization code
document.addEventListener('DOMContentLoaded', () => {
    initializeScreens();
    showScreen('welcome'); // Show welcome screen first
    // Initialize game elements references
    if (typeof basketList === 'undefined') {
        window.basketList = document.getElementById("basketList");
        window.platesGrid = document.getElementById("platesGrid");
        window.scoreValue = document.getElementById("scoreValue");
        window.progressFill = document.getElementById("progressFill");
        window.heartsContainer = document.getElementById("heartsContainer");
    }
});
